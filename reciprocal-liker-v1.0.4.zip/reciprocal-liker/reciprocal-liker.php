<?php
/**
 * Plugin Name: Reciprocal Liker
 * Description: Queues and optionally reciprocates WordPress.com post likes with randomized delays, OAuth setup, dry-run mode, readable logging, duplicate protection, and scan options.
 * Version: 1.0.4
 * Author: Community
 * License: GPL-2.0-or-later
 * Text Domain: reciprocal-liker
 */

if (!defined('ABSPATH')) { exit; }

class RCL_Reciprocal_Liker {
    const OPT = 'rcl_settings';
    const LOG = 'rcl_log';
    const QUEUE = 'rcl_queue';
    const SEEN = 'rcl_seen_likes';
    const CRON_HOOK = 'rcl_hourly_worker';

    public function __construct() {
        add_action('admin_menu', [$this, 'admin_menu']);
        add_action('admin_post_rcl_save_settings', [$this, 'save_settings']);
        add_action('admin_post_rcl_exchange_code', [$this, 'exchange_code']);
        add_action('admin_post_rcl_scan', [$this, 'scan_now']);
        add_action('admin_post_rcl_process', [$this, 'process_now']);
        add_action('admin_post_rcl_clear_log', [$this, 'clear_log']);
        add_action('admin_post_rcl_clear_queue', [$this, 'clear_queue']);
        add_action(self::CRON_HOOK, [$this, 'worker']);
        register_activation_hook(__FILE__, [__CLASS__, 'activate']);
        register_deactivation_hook(__FILE__, [__CLASS__, 'deactivate']);
    }

    public static function defaults() {
        return [
            'client_id' => '',
            'client_secret' => '',
            'access_token' => '',
            'blog_id' => '',
            'blog_url' => '',
            'site' => '',
            'scan_mode' => 'notifications',
            'recent_posts' => 10,
            'delay_min_minutes' => 1,
            'delay_max_minutes' => 180,
            'hourly_enabled' => 0,
            'dry_run' => 1,
            'max_per_run' => 3,
        ];
    }

    public static function activate() {
        if (!wp_next_scheduled(self::CRON_HOOK)) {
            wp_schedule_event(time() + 300, 'hourly', self::CRON_HOOK);
        }
    }

    public static function deactivate() {
        $ts = wp_next_scheduled(self::CRON_HOOK);
        if ($ts) wp_unschedule_event($ts, self::CRON_HOOK);
    }

    private function settings() {
        $settings = wp_parse_args(get_option(self::OPT, []), self::defaults());

        // Gentle migration for older builds that only had blog_url.
        if (empty($settings['site']) && !empty($settings['blog_url'])) {
            $settings['site'] = preg_replace('#^https?://#', '', rtrim($settings['blog_url'], '/'));
        }

        return $settings;
    }

    private function log($level, $msg, $context = []) {
        $log = get_option(self::LOG, []);
        if (!is_array($log)) $log = [];
        $log[] = [
            'time' => current_time('mysql'),
            'level' => sanitize_text_field($level),
            'message' => sanitize_text_field($msg),
            'context' => $this->sanitize_context($context),
        ];
        update_option(self::LOG, array_slice($log, -250), false);
    }

    private function sanitize_context($context) {
        $json = wp_json_encode($context);
        if (!$json) return [];
        $json = preg_replace('/("?(access_token|client_secret|token|authorization|code)"?\s*[:=]\s*)"?[^",}\s]+/i', '$1"[redacted]"', $json);
        $json = preg_replace('/Bearer\s+[A-Za-z0-9\-\._~\+\/]+=*/i', 'Bearer [redacted]', $json);
        $decoded = json_decode($json, true);
        return is_array($decoded) ? $decoded : [];
    }

    public function admin_menu() {
        add_options_page('Reciprocal Liker', 'Reciprocal Liker', 'manage_options', 'reciprocal-liker', [$this, 'admin_page']);
    }

    public function admin_page() {
        if (!current_user_can('manage_options')) return;
        $s = $this->settings();
        $redirect = admin_url('admin-post.php?action=rcl_exchange_code');
        $auth_url = '';
        if (!empty($s['client_id'])) {
            $auth_url = add_query_arg([
                'client_id' => $s['client_id'],
                'redirect_uri' => $redirect,
                'response_type' => 'code',
            ], 'https://public-api.wordpress.com/oauth2/authorize');
        }

        $queue = get_option(self::QUEUE, []);
        if (!is_array($queue)) $queue = [];
        $log = array_reverse(get_option(self::LOG, []));
        if (!is_array($log)) $log = [];
        ?>
        <div class="wrap">
            <h1>Reciprocal Liker <span style="font-size:14px;font-weight:400;">v1.0.4</span></h1>
            <p>Queues reciprocal WordPress.com likes and processes them after a randomized delay.</p>

            <h2>Settings</h2>
            <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
                <?php wp_nonce_field('rcl_save_settings'); ?>
                <input type="hidden" name="action" value="rcl_save_settings" />
                <table class="form-table">
                    <tr><th>Client ID</th><td><input class="regular-text" name="client_id" value="<?php echo esc_attr($s['client_id']); ?>"></td></tr>
                    <tr><th>Client Secret</th><td><input class="regular-text" type="password" name="client_secret" value="<?php echo esc_attr($s['client_secret']); ?>"></td></tr>
                    <tr><th>Access Token</th><td><input class="large-text" type="password" name="access_token" value="<?php echo esc_attr($s['access_token']); ?>"><p class="description">Preserved during plugin updates. Re-authorize only if this is blank or invalid.</p></td></tr>
                    <tr><th>Blog ID</th><td><input class="regular-text" name="blog_id" value="<?php echo esc_attr($s['blog_id']); ?>"></td></tr>
                    <tr><th>Blog URL</th><td><input class="regular-text" name="blog_url" value="<?php echo esc_attr($s['blog_url']); ?>"></td></tr>
                    <tr><th>Your site/domain</th><td><input class="regular-text" name="site" value="<?php echo esc_attr($s['site']); ?>"><p class="description">Used by recent-post scan mode. Example: example.com</p></td></tr>
                    <tr>
                        <th>Scan Mode</th>
                        <td>
                            <select name="scan_mode">
                                <option value="notifications" <?php selected($s['scan_mode'], 'notifications'); ?>>Notifications only</option>
                                <option value="recent_posts" <?php selected($s['scan_mode'], 'recent_posts'); ?>>Recent posts only</option>
                                <option value="both" <?php selected($s['scan_mode'], 'both'); ?>>Both notifications and recent posts</option>
                            </select>
                        </td>
                    </tr>
                    <tr><th>Recent Posts to Scan</th><td><input type="number" min="1" max="50" name="recent_posts" value="<?php echo esc_attr($s['recent_posts']); ?>"></td></tr>
                    <tr><th>Delay Window</th><td><input type="number" min="1" max="180" name="delay_min_minutes" value="<?php echo esc_attr($s['delay_min_minutes']); ?>"> to <input type="number" min="1" max="180" name="delay_max_minutes" value="<?php echo esc_attr($s['delay_max_minutes']); ?>"> minutes <p class="description">Default: 1 to 180 minutes.</p></td></tr>
                    <tr><th>Max Likes Per Run</th><td><input type="number" min="1" max="20" name="max_per_run" value="<?php echo esc_attr($s['max_per_run']); ?>"></td></tr>
                    <tr><th>Dry Run</th><td><label><input type="checkbox" name="dry_run" value="1" <?php checked($s['dry_run'], 1); ?>> Log actions without liking posts</label></td></tr>
                    <tr><th>Hourly Automation</th><td><label><input type="checkbox" name="hourly_enabled" value="1" <?php checked($s['hourly_enabled'], 1); ?>> Enable hourly scan/process</label></td></tr>
                </table>
                <?php submit_button('Save Settings'); ?>
            </form>

            <h2>OAuth</h2>
            <p>Redirect URI for your WordPress.com app:</p>
            <code><?php echo esc_html($redirect); ?></code>
            <p>
                <?php if ($auth_url): ?>
                    <a class="button button-primary" href="<?php echo esc_url($auth_url); ?>">Authorize with WordPress.com</a>
                <?php else: ?>
                    Save a Client ID first, then this button will appear.
                <?php endif; ?>
            </p>

            <h2>Manual Controls</h2>
            <p>
                <a class="button" href="<?php echo esc_url(wp_nonce_url(admin_url('admin-post.php?action=rcl_scan'), 'rcl_scan')); ?>">Scan Likes</a>
                <a class="button" href="<?php echo esc_url(wp_nonce_url(admin_url('admin-post.php?action=rcl_process'), 'rcl_process')); ?>">Process Queue</a>
                <a class="button" href="<?php echo esc_url(wp_nonce_url(admin_url('admin-post.php?action=rcl_clear_log'), 'rcl_clear_log')); ?>">Clear Log</a>
                <a class="button" href="<?php echo esc_url(wp_nonce_url(admin_url('admin-post.php?action=rcl_clear_queue'), 'rcl_clear_queue')); ?>">Clear Queue/Seen</a>
            </p>

            <h2>Queue</h2>
            <?php echo $this->render_queue_table($queue); ?>

            <h2>Log</h2>
            <?php echo $this->render_log_table($log); ?>
        </div>
        <?php
    }

    private function human_time_remaining($timestamp) {
        $remaining = intval($timestamp) - time();

        if ($remaining <= 0) {
            return 'Due now';
        }

        $hours = floor($remaining / 3600);
        $minutes = floor(($remaining % 3600) / 60);
        $seconds = $remaining % 60;

        if ($hours > 0) {
            return $hours . 'h ' . $minutes . 'm';
        }

        if ($minutes > 0) {
            return $minutes . 'm ' . $seconds . 's';
        }

        return $seconds . 's';
    }

    private function queue_status_label($job) {
        $status = $job['status'] ?? 'queued';
        $run_after = intval($job['run_after'] ?? $job['scheduled_at'] ?? 0);

        if (($status === 'queued' || $status === 'dry_run_due') && $run_after > 0 && time() >= $run_after) {
            return 'Ready';
        }

        if ($status === 'dry_run_due') return 'Dry-run ready';
        if ($status === 'queued') return 'Queued';
        if ($status === 'done') return 'Complete';
        if ($status === 'error') return 'Failed';
        if ($status === 'needs_manual_review') return 'Needs review';

        return ucfirst(str_replace('_', ' ', $status));
    }

    private function queue_row_style($job) {
        $status = $job['status'] ?? 'queued';
        $run_after = intval($job['run_after'] ?? $job['scheduled_at'] ?? 0);
        $remaining = $run_after - time();

        if ($status === 'error' || $status === 'needs_manual_review') {
            return 'background:#fde8e8;';
        }

        if ($run_after > 0 && $remaining <= 0) {
            return 'background:#e8f7e8;';
        }

        if ($run_after > 0 && $remaining <= 1800) {
            return 'background:#fff8d7;';
        }

        return '';
    }

    private function render_queue_table($queue) {
        if (empty($queue) || !is_array($queue)) return '<p><em>No queued items.</em></p>';

        uasort($queue, function($a, $b) {
            $a_time = intval($a['run_after'] ?? $a['scheduled_at'] ?? 0);
            $b_time = intval($b['run_after'] ?? $b['scheduled_at'] ?? 0);
            return $a_time <=> $b_time;
        });

        $now = time();
        $queued_count = count($queue);
        $ready_count = 0;
        $failed_count = 0;
        $next_run = null;

        foreach ($queue as $job) {
            $status = $job['status'] ?? 'queued';
            $run_after = intval($job['run_after'] ?? $job['scheduled_at'] ?? 0);

            if (($status === 'error') || ($status === 'needs_manual_review')) {
                $failed_count++;
            }

            if ($run_after > 0 && $run_after <= $now && ($status === 'queued' || $status === 'dry_run_due')) {
                $ready_count++;
            }

            if ($run_after > $now && ($status === 'queued' || $status === 'dry_run_due')) {
                if ($next_run === null || $run_after < $next_run) {
                    $next_run = $run_after;
                }
            }
        }

        ob_start(); ?>
        <div style="display:flex;gap:12px;flex-wrap:wrap;margin:8px 0 14px 0;">
            <div style="background:#fff;border:1px solid #ccd0d4;padding:10px 14px;min-width:120px;">
                <strong><?php echo esc_html($queued_count); ?></strong><br>
                <span>In queue</span>
            </div>
            <div style="background:#fff;border:1px solid #ccd0d4;padding:10px 14px;min-width:120px;">
                <strong><?php echo esc_html($ready_count); ?></strong><br>
                <span>Ready now</span>
            </div>
            <div style="background:#fff;border:1px solid #ccd0d4;padding:10px 14px;min-width:120px;">
                <strong><?php echo esc_html($failed_count); ?></strong><br>
                <span>Needs attention</span>
            </div>
            <div style="background:#fff;border:1px solid #ccd0d4;padding:10px 14px;min-width:160px;">
                <strong><?php echo esc_html($next_run ? $this->human_time_remaining($next_run) : ($ready_count ? 'Due now' : 'None')); ?></strong><br>
                <span>Next response</span>
            </div>
        </div>

        <table class="widefat striped">
            <thead><tr><th>Status</th><th>Run After</th><th>Liker</th><th>Target Post</th><th>Responds In</th><th>Attempts</th></tr></thead>
            <tbody>
            <?php foreach ($queue as $job):
                $c = $job['candidate'] ?? $job;
                $run_after = intval($job['run_after'] ?? $job['scheduled_at'] ?? 0);
                ?>
                <tr style="<?php echo esc_attr($this->queue_row_style($job)); ?>">
                    <td><?php echo esc_html($this->queue_status_label($job)); ?></td>
                    <td><?php echo esc_html($run_after ? date_i18n('Y-m-d H:i:s', $run_after) : ''); ?></td>
                    <td><?php echo esc_html($c['liker_name'] ?? $c['liker_site_url'] ?? $c['site_url'] ?? ''); ?></td>
                    <td><?php echo !empty($c['post_url']) || !empty($c['target_url']) ? '<a href="'.esc_url($c['post_url'] ?? $c['target_url']).'" target="_blank" rel="noopener">'.esc_html($c['post_title'] ?? $c['target_title'] ?? 'View post').'</a>' : esc_html($c['post_id'] ?? $c['target_post_id'] ?? ''); ?></td>
                    <td><strong><?php echo esc_html($run_after ? $this->human_time_remaining($run_after) : ''); ?></strong></td>
                    <td><?php echo esc_html($job['attempts'] ?? 0); ?></td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
        <p class="description">Rows turn green when ready, yellow inside 30 minutes, and red when attention is needed.</p>
        <?php return ob_get_clean();
    }

    private function render_log_table($log) {
        if (empty($log) || !is_array($log)) return '<p><em>No log entries.</em></p>';
        ob_start(); ?>
        <table class="widefat striped">
            <thead><tr><th style="width:160px;">Time</th><th style="width:90px;">Level</th><th>Message</th><th>Details</th></tr></thead>
            <tbody>
            <?php foreach ($log as $entry): ?>
                <tr>
                    <td><?php echo esc_html($entry['time'] ?? ''); ?></td>
                    <td><?php echo esc_html(strtoupper($entry['level'] ?? 'INFO')); ?></td>
                    <td><?php echo esc_html($entry['message'] ?? ''); ?></td>
                    <td><pre style="white-space:pre-wrap;margin:0;"><?php echo esc_html($this->pretty_context($entry['context'] ?? [])); ?></pre></td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
        <?php return ob_get_clean();
    }

    private function pretty_context($context) {
        if (empty($context)) return '';
        return wp_json_encode($context, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES);
    }

    public function save_settings() {
        if (!current_user_can('manage_options') || !check_admin_referer('rcl_save_settings')) wp_die('Not allowed');
        $new = [
            'client_id' => sanitize_text_field($_POST['client_id'] ?? ''),
            'client_secret' => sanitize_text_field($_POST['client_secret'] ?? ''),
            'access_token' => sanitize_text_field($_POST['access_token'] ?? ''),
            'blog_id' => sanitize_text_field($_POST['blog_id'] ?? ''),
            'blog_url' => esc_url_raw($_POST['blog_url'] ?? ''),
            'site' => sanitize_text_field($_POST['site'] ?? ''),
            'scan_mode' => sanitize_text_field($_POST['scan_mode'] ?? 'notifications'),
            'recent_posts' => max(1, min(50, intval($_POST['recent_posts'] ?? 10))),
            'delay_min_minutes' => max(1, min(180, intval($_POST['delay_min_minutes'] ?? 1))),
            'delay_max_minutes' => max(1, min(180, intval($_POST['delay_max_minutes'] ?? 180))),
            'hourly_enabled' => empty($_POST['hourly_enabled']) ? 0 : 1,
            'dry_run' => empty($_POST['dry_run']) ? 0 : 1,
            'max_per_run' => max(1, min(20, intval($_POST['max_per_run'] ?? 3))),
        ];

        if (!in_array($new['scan_mode'], ['notifications', 'recent_posts', 'both'], true)) $new['scan_mode'] = 'notifications';
        if ($new['delay_max_minutes'] < $new['delay_min_minutes']) $new['delay_max_minutes'] = $new['delay_min_minutes'];
        if (empty($new['site']) && !empty($new['blog_url'])) $new['site'] = preg_replace('#^https?://#', '', rtrim($new['blog_url'], '/'));

        update_option(self::OPT, $new, false);
        $this->log('info', 'Settings saved');
        wp_safe_redirect(admin_url('options-general.php?page=reciprocal-liker'));
        exit;
    }

    public function exchange_code() {
        if (!current_user_can('manage_options')) wp_die('Not allowed');
        $code = sanitize_text_field($_GET['code'] ?? '');
        if (!$code) {
            $this->log('error', 'OAuth callback missing code');
            wp_safe_redirect(admin_url('options-general.php?page=reciprocal-liker'));
            exit;
        }

        $s = $this->settings();
        $response = wp_remote_post('https://public-api.wordpress.com/oauth2/token', [
            'timeout' => 20,
            'body' => [
                'client_id' => $s['client_id'],
                'client_secret' => $s['client_secret'],
                'redirect_uri' => admin_url('admin-post.php?action=rcl_exchange_code'),
                'code' => $code,
                'grant_type' => 'authorization_code',
            ],
        ]);

        if (is_wp_error($response)) {
            $this->log('error', 'OAuth token exchange failed', ['error' => $response->get_error_message()]);
        } else {
            $body = json_decode(wp_remote_retrieve_body($response), true);
            if (!empty($body['access_token'])) {
                $s['access_token'] = sanitize_text_field($body['access_token']);
                $s['blog_id'] = sanitize_text_field($body['blog_id'] ?? $s['blog_id']);
                $s['blog_url'] = esc_url_raw($body['blog_url'] ?? $s['blog_url']);
                if (empty($s['site']) && !empty($s['blog_url'])) $s['site'] = preg_replace('#^https?://#', '', rtrim($s['blog_url'], '/'));
                update_option(self::OPT, $s, false);
                $this->log('success', 'OAuth token saved', ['blog_id' => $s['blog_id'], 'blog_url' => $s['blog_url']]);
            } else {
                $this->log('error', 'OAuth token exchange returned no token', ['status' => wp_remote_retrieve_response_code($response), 'body' => $body]);
            }
        }

        wp_safe_redirect(admin_url('options-general.php?page=reciprocal-liker'));
        exit;
    }

    public function scan_now() {
        if (!current_user_can('manage_options') || !check_admin_referer('rcl_scan')) wp_die('Not allowed');
        $this->scan();
        wp_safe_redirect(admin_url('options-general.php?page=reciprocal-liker'));
        exit;
    }

    public function process_now() {
        if (!current_user_can('manage_options') || !check_admin_referer('rcl_process')) wp_die('Not allowed');
        $this->process_queue();
        wp_safe_redirect(admin_url('options-general.php?page=reciprocal-liker'));
        exit;
    }

    public function clear_log() {
        if (!current_user_can('manage_options') || !check_admin_referer('rcl_clear_log')) wp_die('Not allowed');
        update_option(self::LOG, [], false);
        wp_safe_redirect(admin_url('options-general.php?page=reciprocal-liker'));
        exit;
    }

    public function clear_queue() {
        if (!current_user_can('manage_options') || !check_admin_referer('rcl_clear_queue')) wp_die('Not allowed');
        update_option(self::QUEUE, [], false);
        update_option(self::SEEN, [], false);
        $this->log('success', 'Queue and seen history cleared');
        wp_safe_redirect(admin_url('options-general.php?page=reciprocal-liker'));
        exit;
    }

    public function worker() {
        $s = $this->settings();
        if (empty($s['hourly_enabled'])) {
            $this->log('info', 'Hourly worker skipped because automation is disabled');
            return;
        }
        $this->process_queue();
        $this->scan();
    }

    private function api_get($path_or_url) {
        $s = $this->settings();
        if (empty($s['access_token'])) return new WP_Error('rcl_no_token', 'Missing access token');
        $url = (strpos($path_or_url, 'http') === 0) ? $path_or_url : 'https://public-api.wordpress.com' . $path_or_url;
        return wp_remote_get($url, [
            'timeout' => 20,
            'headers' => ['Authorization' => 'Bearer ' . $s['access_token']],
        ]);
    }

    private function api_post($path) {
        $s = $this->settings();
        if (empty($s['access_token'])) return new WP_Error('rcl_no_token', 'Missing access token');
        return wp_remote_post('https://public-api.wordpress.com' . $path, [
            'timeout' => 20,
            'headers' => ['Authorization' => 'Bearer ' . $s['access_token']],
        ]);
    }

    private function scan() {
        $s = $this->settings();

        if ($s['scan_mode'] === 'notifications' || $s['scan_mode'] === 'both') {
            $this->scan_notifications();
        }

        if ($s['scan_mode'] === 'recent_posts' || $s['scan_mode'] === 'both') {
            $this->scan_recent_posts();
        }
    }

    private function scan_notifications() {
        $response = $this->api_get('/rest/v1.1/notifications/?number=50');
        if (is_wp_error($response)) {
            $this->log('error', 'Notification scan failed', ['error' => $response->get_error_message()]);
            return;
        }

        $code = wp_remote_retrieve_response_code($response);
        $body = json_decode(wp_remote_retrieve_body($response), true);
        if ($code < 200 || $code >= 300 || !is_array($body)) {
            $this->log('error', 'Notification scan returned unexpected response', ['status' => $code, 'body' => $body]);
            return;
        }

        $items = $body['notifications'] ?? $body;
        if (!is_array($items)) {
            $this->log('warning', 'Notification scan found no parseable notification list', ['body_keys' => array_keys($body)]);
            return;
        }

        $queued = 0;
        $likes_seen = 0;
        foreach ($items as $item) {
            if (($item['type'] ?? '') !== 'like' && strpos(strtolower(wp_json_encode($item)), 'like') === false) continue;
            $likes_seen++;

            $likers = $this->extract_likers_from_notification($item);
            if (empty($likers)) {
                $this->log('warning', 'Like notification found, but no liker site could be extracted', [
                    'debug' => $this->compact_notification_debug($item),
                ]);
                continue;
            }

            foreach ($likers as $liker) {
                if (empty($liker['site_id'])) continue;

                if ($this->is_own_site_id($liker['site_id']) || $this->is_own_url($liker['site_url'] ?? '')) {
                    $this->log('info', 'Skipped own site from notification parser', [
                        'site_id' => $liker['site_id'],
                        'site_url' => $liker['site_url'] ?? '',
                    ]);
                    continue;
                }

                $latest = $this->fetch_latest_post_for_site($liker['site_id']);
                if (!$latest) {
                    $this->log('info', 'Liker has no visible recent post available', $liker);
                    continue;
                }

                if ($this->is_own_site_id($latest['site_id'] ?? '') || $this->is_own_url($latest['post_url'] ?? '')) {
                    $this->log('info', 'Skipped target because it belongs to this site', [
                        'target_post' => $latest['post_url'] ?? '',
                        'liker_site' => $liker['site_url'] ?? '',
                    ]);
                    continue;
                }

                if ($this->is_source_post_url($latest['post_url'] ?? '', $item['url'] ?? '')) {
                    $this->log('info', 'Skipped notification source post as reciprocal target', [
                        'target_post' => $latest['post_url'] ?? '',
                    ]);
                    continue;
                }

                $candidate = array_merge($latest, [
                    'liker_site_id' => $liker['site_id'],
                    'liker_site_url' => $liker['site_url'] ?? '',
                    'liker_user_id' => $liker['user_id'] ?? '',
                    'liker_name' => $liker['name'] ?: ($liker['site_url'] ?? 'unknown'),
                    'source' => 'notifications',
                    'source_notification_id' => $item['id'] ?? '',
                    'source_post_url' => $item['url'] ?? '',
                ]);

                if ($this->enqueue($candidate)) $queued++;
            }
        }
        $this->log('success', 'Notification scan complete', ['like_notifications_seen' => $likes_seen, 'queued' => $queued]);
    }

    private function normalize_host($url_or_host) {
        $value = trim(strtolower(strval($url_or_host)));
        if ($value === '') return '';
        if (strpos($value, 'http://') !== 0 && strpos($value, 'https://') !== 0) {
            $value = 'https://' . $value;
        }
        $host = parse_url($value, PHP_URL_HOST);
        if (!$host) return '';
        return preg_replace('/^www\./', '', strtolower($host));
    }

    private function is_own_site_id($site_id) {
        $s = $this->settings();
        return !empty($s['blog_id']) && strval($site_id) === strval($s['blog_id']);
    }

    private function is_own_url($url) {
        $s = $this->settings();
        $own_hosts = array_filter([
            $this->normalize_host($s['blog_url'] ?? ''),
            $this->normalize_host($s['site'] ?? ''),
        ]);

        $host = $this->normalize_host($url);
        return $host && in_array($host, $own_hosts, true);
    }

    private function is_source_post_url($candidate_url, $source_url) {
        if (empty($candidate_url) || empty($source_url)) return false;
        return rtrim(strtolower($candidate_url), '/') === rtrim(strtolower($source_url), '/');
    }

    private function extract_likers_from_notification($item) {
        $likers = [];

        // Known WordPress.com notification shape:
        // subject[0].ranges[] contains user entries with site_id and url.
        $subjects = $item['subject'] ?? [];
        if (isset($subjects['ranges'])) $subjects = [$subjects];

        foreach ((array)$subjects as $subject) {
            $ranges = $subject['ranges'] ?? [];
            foreach ((array)$ranges as $range) {
                if (($range['type'] ?? '') !== 'user') continue;
                if (empty($range['site_id']) && empty($range['site_ID'])) continue;

                $site_id = $range['site_id'] ?? $range['site_ID'];

                $likers[] = [
                    'site_id' => sanitize_text_field($site_id),
                    'site_url' => esc_url_raw($range['url'] ?? $range['site_URL'] ?? ''),
                    'user_id' => sanitize_text_field($range['id'] ?? $range['ID'] ?? ''),
                    'name' => sanitize_text_field($range['name'] ?? $range['text'] ?? ''),
                ];
            }
        }

        // Fallback: recursively search the entire notification for user-shaped
        // objects with site IDs. Self-contained to avoid helper-method load issues.
        if (empty($likers)) {
            $found = [];
            $walker = function($node) use (&$walker, &$found) {
                if (!is_array($node)) return;

                $type = strtolower(strval($node['type'] ?? ''));
                $site_id = $node['site_id'] ?? $node['site_ID'] ?? $node['siteId'] ?? null;
                $url = $node['url'] ?? $node['site_URL'] ?? $node['site_url'] ?? '';

                if ($site_id && ($type === 'user' || isset($node['id']) || isset($node['ID']))) {
                    $key = sanitize_text_field($site_id);
                    if (!isset($found[$key])) {
                        $found[$key] = [
                            'site_id' => sanitize_text_field($site_id),
                            'site_url' => esc_url_raw($url),
                            'user_id' => sanitize_text_field($node['id'] ?? $node['ID'] ?? ''),
                            'name' => sanitize_text_field($node['name'] ?? $node['text'] ?? $node['login'] ?? ''),
                        ];
                    }
                }

                foreach ($node as $child) {
                    if (is_array($child)) $walker($child);
                }
            };

            $walker($item);
            $likers = array_values($found);
        }

        return $likers;
    }

    private function compact_notification_debug($item) {
        $site_ids = [];
        $urls = [];

        $collector = function($node) use (&$collector, &$site_ids, &$urls) {
            if (!is_array($node)) return;

            foreach ($node as $key => $value) {
                $k = strtolower(strval($key));

                if (($k === 'site_id' || $k === 'siteid' || $key === 'site_ID') && !is_array($value)) {
                    $site_ids[] = strval($value);
                }

                if (($k === 'url' || $k === 'site_url' || $key === 'site_URL') && !is_array($value)) {
                    $urls[] = strval($value);
                }

                if (is_array($value)) $collector($value);
            }
        };

        $collector($item);

        return [
            'top_level_keys' => is_array($item) ? array_keys($item) : [],
            'id' => $item['id'] ?? $item['ID'] ?? '',
            'type' => $item['type'] ?? '',
            'url' => $item['url'] ?? '',
            'subject_type' => isset($item['subject']) ? gettype($item['subject']) : 'missing',
            'subject_sample' => $item['subject'] ?? null,
            'available_site_ids' => array_values(array_unique(array_slice($site_ids, 0, 20))),
            'available_urls' => array_values(array_unique(array_slice($urls, 0, 20))),
        ];
    }

    private function scan_recent_posts() {
        $s = $this->settings();
        $site = trim($s['site'] ?: preg_replace('#^https?://#', '', rtrim($s['blog_url'], '/')));
        if (empty($site)) {
            $this->log('error', 'Recent-post scan skipped because site/domain is missing');
            return;
        }

        $recent_count = max(1, min(50, intval($s['recent_posts'])));
        $response = $this->api_get('/rest/v1.1/sites/' . rawurlencode($site) . '/posts/?number=' . $recent_count . '&order_by=date&order=DESC&status=publish');

        if (is_wp_error($response)) {
            $this->log('error', 'Could not fetch your recent posts', ['error' => $response->get_error_message()]);
            return;
        }

        $code = wp_remote_retrieve_response_code($response);
        $body = json_decode(wp_remote_retrieve_body($response), true);
        if ($code < 200 || $code >= 300 || empty($body['posts'])) {
            $this->log('warning', 'Could not fetch your recent posts', ['status' => $code, 'body' => $body]);
            return;
        }

        $unique = [];
        foreach ($body['posts'] as $my_post) {
            if (empty($my_post['ID'])) continue;
            $likes = $this->api_get('/rest/v1.1/sites/' . rawurlencode($site) . '/posts/' . intval($my_post['ID']) . '/likes?number=100');
            if (is_wp_error($likes)) continue;

            $likes_code = wp_remote_retrieve_response_code($likes);
            $likes_body = json_decode(wp_remote_retrieve_body($likes), true);
            if ($likes_code < 200 || $likes_code >= 300 || empty($likes_body['likes'])) continue;

            foreach ($likes_body['likes'] as $liker) {
                $sid = $liker['site_ID'] ?? null;
                if (!$sid) continue;
                if (isset($liker['site_visible']) && $liker['site_visible'] === false) continue;
                $unique[intval($sid)] = $liker;
            }
        }

        $queued = 0;
        foreach ($unique as $liker) {
            $sid = $liker['site_ID'] ?? null;
            if (!$sid) continue;
            $latest = $this->fetch_latest_post_for_site($sid);
            if (!$latest) continue;

            if ($this->is_own_site_id($sid) || $this->is_own_url($liker['site_URL'] ?? '')) {
                continue;
            }

            if ($this->is_own_site_id($latest['site_id'] ?? '') || $this->is_own_url($latest['post_url'] ?? '')) {
                continue;
            }

            $candidate = array_merge($latest, [
                'liker_site_id' => $sid,
                'liker_site_url' => $liker['site_URL'] ?? '',
                'liker_user_id' => $liker['ID'] ?? '',
                'liker_name' => $liker['name'] ?? ($liker['login'] ?? 'unknown'),
                'source' => 'recent_posts',
            ]);

            if ($this->enqueue($candidate)) $queued++;
        }

        $this->log('success', 'Recent-post scan complete', [
            'your_posts_scanned' => count($body['posts']),
            'unique_liker_sites' => count($unique),
            'queued' => $queued,
        ]);
    }

    private function fetch_latest_post_for_site($site_id) {
        $path = '/rest/v1.1/sites/' . rawurlencode($site_id) . '/posts/?number=1&status=publish&order_by=date&order=DESC';
        $response = $this->api_get($path);
        if (is_wp_error($response)) {
            $this->log('error', 'Could not fetch liker recent post', ['site_id' => $site_id, 'error' => $response->get_error_message()]);
            return null;
        }

        $code = wp_remote_retrieve_response_code($response);
        $body = json_decode(wp_remote_retrieve_body($response), true);
        if ($code < 200 || $code >= 300 || !is_array($body)) {
            $this->log('warning', 'Could not fetch liker recent post', ['site_id' => $site_id, 'status' => $code, 'body' => $body]);
            return null;
        }

        $post = $body['posts'][0] ?? null;
        if (!$post || empty($post['ID'])) return null;
        if (!empty($post['password'])) return null;
        if (!empty($post['status']) && $post['status'] !== 'publish') return null;

        return [
            'site_id' => sanitize_text_field($site_id),
            'post_id' => sanitize_text_field($post['ID']),
            'post_title' => sanitize_text_field($post['title'] ?? ''),
            'post_url' => esc_url_raw($post['URL'] ?? ''),
            'already_liked' => !empty($post['i_like']),
        ];
    }

    private function enqueue($candidate) {
        $queue = get_option(self::QUEUE, []);
        if (!is_array($queue)) $queue = [];
        $seen = get_option(self::SEEN, []);
        if (!is_array($seen)) $seen = [];

        if ($this->is_own_site_id($candidate['site_id'] ?? '') || $this->is_own_url($candidate['post_url'] ?? '')) {
            $this->log('info', 'Skipped own post; Reciprocal Liker will not respond to itself', [
                'target_post' => $candidate['post_url'] ?? '',
                'target_title' => $candidate['post_title'] ?? '',
            ]);
            return false;
        }

        $key = md5(($candidate['site_id'] ?? '') . ':' . ($candidate['post_id'] ?? ''));
        if (isset($seen[$key])) {
            $this->log('info', 'Skipped already processed post', ['target_post' => $candidate['post_url'] ?? '']);
            return false;
        }

        if (!empty($candidate['already_liked'])) {
            $seen[$key] = [
                'status' => 'already_liked_before_plugin_action',
                'target_post' => $candidate['post_url'] ?? '',
                'time' => current_time('mysql'),
            ];
            update_option(self::SEEN, $seen, false);
            $this->log('info', 'Skipped post because it is already liked', ['target_post' => $candidate['post_url'] ?? '']);
            return false;
        }

        if (isset($queue[$key])) {
            $this->log('info', 'Skipped duplicate queued post', [
                'target_post' => $candidate['post_url'] ?? '',
                'liker_site' => $candidate['liker_site_url'] ?? '',
            ]);
            return false;
        }

        $s = $this->settings();
        $delay = wp_rand(intval($s['delay_min_minutes']), intval($s['delay_max_minutes']));
        $queue[$key] = [
            'candidate' => $candidate,
            'created_at' => time(),
            'run_after' => time() + ($delay * 60),
            'delay_minutes' => $delay,
            'status' => 'queued',
            'attempts' => 0,
        ];

        update_option(self::QUEUE, $queue, false);
        $this->log('success', 'Queued reciprocal like', [
            'delay_minutes' => $delay,
            'liker' => $candidate['liker_name'] ?? '',
            'liker_site' => $candidate['liker_site_url'] ?? '',
            'target_post' => $candidate['post_url'] ?? '',
            'target_title' => $candidate['post_title'] ?? '',
            'source' => $candidate['source'] ?? '',
        ]);
        return true;
    }

    private function process_queue() {
        $s = $this->settings();
        $queue = get_option(self::QUEUE, []);
        if (!is_array($queue)) $queue = [];
        $seen = get_option(self::SEEN, []);
        if (!is_array($seen)) $seen = [];

        $processed = 0;
        $due = 0;

        foreach ($queue as $key => &$job) {
            if ($processed >= intval($s['max_per_run'])) break;
            if (($job['status'] ?? '') !== 'queued' && ($job['status'] ?? '') !== 'dry_run_due') continue;
            if (time() < intval($job['run_after'] ?? 0)) continue;

            $due++;
            $job['attempts'] = intval($job['attempts'] ?? 0) + 1;
            $candidate = $job['candidate'] ?? [];

            if (empty($candidate['site_id']) || empty($candidate['post_id'])) {
                $job['status'] = 'needs_manual_review';
                $this->log('warning', 'Queued item needs manual review; missing site_id or post_id', $candidate);
                continue;
            }

            if (!empty($s['dry_run'])) {
                $job['status'] = 'dry_run_due';
                $this->log('success', 'Dry run: would like post', [
                    'target_post' => $candidate['post_url'] ?? '',
                    'target_title' => $candidate['post_title'] ?? '',
                    'liker' => $candidate['liker_name'] ?? '',
                ]);
                continue;
            }

            $path = '/rest/v1.1/sites/' . rawurlencode($candidate['site_id']) . '/posts/' . rawurlencode($candidate['post_id']) . '/likes/new';
            $response = $this->api_post($path);
            if (is_wp_error($response)) {
                $job['status'] = 'error';
                $this->log('error', 'Like request failed', ['error' => $response->get_error_message(), 'target_post' => $candidate['post_url'] ?? '']);
            } else {
                $code = wp_remote_retrieve_response_code($response);
                $body = json_decode(wp_remote_retrieve_body($response), true);
                if ($code >= 200 && $code < 300) {
                    $job['status'] = 'done';
                    $seen[$key] = [
                        'status' => 'liked_after_delay',
                        'target_post' => $candidate['post_url'] ?? '',
                        'target_title' => $candidate['post_title'] ?? '',
                        'time' => current_time('mysql'),
                    ];
                    unset($queue[$key]);
                    $this->log('success', 'Like request completed', [
                        'target_post' => $candidate['post_url'] ?? '',
                        'target_title' => $candidate['post_title'] ?? '',
                    ]);
                } else {
                    $job['status'] = 'error';
                    $this->log('error', 'Like request failed', [
                        'status' => $code,
                        'target_post' => $candidate['post_url'] ?? '',
                        'response' => $body,
                    ]);
                }
            }

            $processed++;
        }
        unset($job);

        update_option(self::QUEUE, $queue, false);
        update_option(self::SEEN, $seen, false);
        $this->log('info', 'Queue processing complete', ['due' => $due, 'processed' => $processed, 'remaining_queue' => count($queue)]);
    }
}

new RCL_Reciprocal_Liker();
