# Reciprocal Liker

Version 1.0.4

Quality-of-life update for the existing **Reciprocal Liker** plugin.

## What changed in 1.0.4

- Replaces the Queue `Delay` column with `Responds In`.
- Adds live remaining-time labels such as `Due now`, `42m 10s`, or `1h 12m`.
- Sorts queue rows by next scheduled response.
- Adds a queue summary panel:
  - In queue
  - Ready now
  - Needs attention
  - Next response
- Adds row highlighting:
  - Green: ready now
  - Yellow: due within 30 minutes
  - Red: failed or needs review
- Keeps all v1.0.3 safety fixes:
  - blocks self-responses
  - blocks source-post self-targets
  - preserves existing OAuth settings

## Update instructions

1. Upload `reciprocal-liker-v1.0.4.zip`.
2. Choose **Replace current with uploaded**.
3. Go to **Settings → Reciprocal Liker**.
4. Confirm the Queue now shows `Responds In`.

You should not need to re-authorize.
